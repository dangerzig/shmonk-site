# Claude Code — Emacs Integration

Add this to your project's `CLAUDE.md` or to `~/.claude/CLAUDE.md` for global use.

---

## Emacs Integration

You have access to the user's Emacs via emacsclient. Use the `ec` wrapper script:

```bash
~/.local/bin/ec -e '(elisp-expression)'
```

### Common operations:

**Open a file (always use new frame):**
```bash
~/.local/bin/ec -e '(find-file-other-frame "/path/to/file")'
```

**Open file and jump to line:**
```bash
~/.local/bin/ec -e '(progn (find-file-other-frame "/path/to/file") (goto-line 42))'
```

**Save current buffer:**
```bash
~/.local/bin/ec -e '(save-buffer)'
```

**Show message to user:**
```bash
~/.local/bin/ec -e '(message "Hello from Claude!")'
```

**Get current buffer name:**
```bash
~/.local/bin/ec -e '(buffer-name)'
```

**Run interactive commands in vterm (e.g. browser auth flows):**
```bash
~/.local/bin/ec -e '(progn (select-frame (make-frame)) (vterm "unique-name") (vterm-send-string "command here\n"))'
```

**Clean up vterm buffers we created (never use `delete-other-frames`):**
```bash
~/.local/bin/ec -e '(when (get-buffer "unique-name") (kill-buffer "unique-name"))'
```

### Notes:
- Always open PDF files in macOS Preview (using `open` command), NOT in Emacs
- Always use `find-file-other-frame` (not `find-file`) to open files in a new frame
- For vterm: use `make-frame` + `(vterm "unique-name")` since Claude Code itself runs in a vterm. A unique buffer name is required or it reuses the existing vterm buffer.
- NEVER use `delete-other-frames` — it closes ALL frames, not just ours. Kill specific buffers instead.
- The Emacs server is started automatically via init.el
