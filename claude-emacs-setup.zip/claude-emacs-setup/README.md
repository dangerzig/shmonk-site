# Claude Code + Emacs Integration

This is my setup for running [Claude Code](https://docs.anthropic.com/en/docs/claude-code) inside Emacs, so that Claude can both run in a terminal buffer and control Emacs itself (open files, launch shells, create keybindings, etc.).

## What's here

- **`ec`** — A small wrapper script that gives Claude (and you) a reliable path to `emacsclient`. On macOS, the binary bundled inside Emacs.app isn't on the default PATH, so this script finds it. If you already have `emacsclient` on your PATH, you can skip this and update the CLAUDE.md references accordingly.

- **`init-excerpt.el`** — The relevant sections of my Emacs config. Includes: starting the Emacs server (so emacsclient works), vterm setup (the terminal emulator Claude runs inside), Claude Code launch commands, auto-revert (so Emacs picks up file changes made by Claude), and exec-path-from-shell (so Emacs inherits your shell's PATH on macOS).

- **`CLAUDE.md`** — The Emacs integration section of my Claude Code configuration. This is what teaches Claude how to interact with Emacs: how to open files, jump to lines, launch terminals, clean up buffers, etc. Place this content in your project's `CLAUDE.md` or in `~/.claude/CLAUDE.md` for global use.

## Setup

1. Install [Claude Code](https://docs.anthropic.com/en/docs/claude-code) and [vterm](https://github.com/akermu/emacs-libvterm) for Emacs.
2. Copy the relevant pieces from `init-excerpt.el` into your `~/.emacs.d/init.el`.
3. Place the `ec` script somewhere on your PATH (e.g., `~/.local/bin/ec`) and make it executable: `chmod +x ~/.local/bin/ec`.
4. Add the contents of `CLAUDE.md` to your Claude Code configuration.
5. Open Emacs, then `C-c c c` to launch Claude Code in a vterm buffer.

Claude will now be able to open files, create frames, launch terminals, and generally operate Emacs as a seamless extension of itself.

## Notes

- Claude Code runs inside vterm, which is itself an Emacs buffer. Claude then uses emacsclient to reach back into Emacs. This two-way communication is what makes the integration feel seamless.
- The `find-file-other-frame` pattern (instead of `find-file`) is important because Claude itself is running in a vterm buffer. Opening files in a new frame avoids clobbering the Claude session.
- The `NEVER use delete-other-frames` warning in CLAUDE.md is there because I learned the hard way that it closes every frame, including the one you're working in.
