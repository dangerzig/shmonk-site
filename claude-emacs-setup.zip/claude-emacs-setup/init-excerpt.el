;;; init-excerpt.el — Emacs config for Claude Code integration
;;; Copy the relevant pieces into your ~/.emacs.d/init.el

;; --- 1. Emacs Server ---
;; Required so that emacsclient (and therefore Claude) can talk to Emacs.
(setq server-client-instructions nil)  ; suppress "waiting clients" message
(unless (server-running-p)
  (server-start))

;; --- 2. Auto-revert ---
;; When Claude edits a file on disk, Emacs automatically picks up the changes.
(global-auto-revert-mode 1)
(setq auto-revert-verbose t)            ; message when a buffer is reverted
(setq auto-revert-avoid-polling t)      ; use OS file notifications, not polling

;; --- 3. PATH fix for macOS ---
;; Ensures Emacs can find git, claude, and other CLI tools.
(use-package exec-path-from-shell
  :ensure t
  :if (memq window-system '(mac ns))
  :init
  (exec-path-from-shell-initialize))

;; --- 4. Terminal Support (vterm) ---
;; Claude Code runs inside vterm. This section also configures keybindings
;; so that standard Mac shortcuts (copy, paste, etc.) work in the terminal.
(use-package vterm
  :ensure t
  :config
  (defun my/vterm-new-frame (name)
    "Open a fresh vterm in a new frame."
    (interactive (list (read-string "vterm name (blank for default): ")))
    (let* ((buf-name (if (string-empty-p name)
                        (generate-new-buffer-name "vterm")
                      (format "vterm-%s" name)))
           (frame (make-frame)))
      (select-frame-set-input-focus frame)
      (vterm buf-name)))

  (global-set-key (kbd "C-c t") 'my/vterm-new-frame)

  ;; Let standard Mac keys pass through to Emacs in vterm buffers
  (define-key vterm-mode-map (kbd "M-c") 'kill-ring-save)
  (define-key vterm-mode-map (kbd "M-v") 'vterm-yank)
  (define-key vterm-mode-map (kbd "M-x") 'kill-region)
  (define-key vterm-mode-map (kbd "M-z") 'undo)
  (define-key vterm-mode-map (kbd "M-n") 'make-frame-command)
  (define-key vterm-mode-map (kbd "M-`") 'other-frame)
  (define-key vterm-mode-map (kbd "M-l") 'execute-extended-command))

;; --- 5. Claude Code Launch Commands ---
;; C-c c c = start a new Claude Code session
;; C-c c r = resume the most recent session
(defun my/claude-code ()
  "Start Claude Code in a vterm buffer."
  (interactive)
  (let ((vterm-shell "claude"))
    (vterm)))

(global-set-key (kbd "C-c c c") 'my/claude-code)

(defun my/claude-code-resume ()
  "Resume the most recent Claude Code conversation."
  (interactive)
  (let ((vterm-shell "claude --continue"))
    (vterm)))

(global-set-key (kbd "C-c c r") 'my/claude-code-resume)
